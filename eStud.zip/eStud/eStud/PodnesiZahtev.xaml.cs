﻿using System;
using eStud.Model;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.IO;
using System.Windows.Xps.Packaging;
using Microsoft.Office.Interop.Word;
using Microsoft.Win32;
using System.Xml.Linq;
using Word = Microsoft.Office.Interop.Word;
using System.Xml;

namespace eStud
{
    /// <summary>
    /// Interaction logic for PodnesiZahtev.xaml
    /// </summary>
    public partial class PodnesiZahtev : UserControl
    {
        public PodnesiZahtev()
        {
           InitializeComponent();
        }
        private void btnPosalji_Click(object sender, RoutedEventArgs e)
        {

        }
        private void tbPodnesi(object sender, TextCompositionEventArgs e) {
            
        }

        private void tbBrtelefona_previewtext(object sender, TextCompositionEventArgs e)
        {   //Onemogucava korisnku da unese slova. Ima dozvolu da unese samo za brojeve
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text); 
        }
        private void btnOdaberi_Click(object sender, RoutedEventArgs e)
        {
            // Initialize an OpenFileDialog 
            OpenFileDialog openFileDialog = new OpenFileDialog();
            
            // Set filter and RestoreDirectory 
            openFileDialog.RestoreDirectory = true;
            openFileDialog.Filter = "Word documents(*.doc;*.docx)|*.doc;*.docx";
            

            bool? result = openFileDialog.ShowDialog();
            if (result == true)
            {
                if (openFileDialog.FileName.Length > 0)
                {
                    txbSelectedWordFile.Text = openFileDialog.SafeFileName;  //FileName;
                }
            }
        }


        





    }
}
